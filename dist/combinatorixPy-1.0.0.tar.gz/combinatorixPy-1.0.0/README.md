# Mixture_Descriptors
This is a project which takes input from two .csv files, first one containing individual descriptors of each components and the second one containing the concentrations values of of each components for each mixtures.
The main function gets threee arguments  1- descriptors file path 2- concentrations file path and 3- output directory (to store a .csv output files) 4- threshold for filtering constant, 5-threshold for filtering pair column correlation ,  and 6- batch_size for calculating pair columns correlation
This code calculates  combinatorila mixture descriptors and return one .csv file . 
install the package using conda install  combinatorial  or pip install combinatorial
